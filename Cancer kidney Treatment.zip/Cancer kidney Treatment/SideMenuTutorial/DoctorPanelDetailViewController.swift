//
//  DoctorPanelDetailViewController.swift
//  Ankur app
//
//  Created by adithya on 9/8/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit
import WebKit
class DoctorPanelDetailViewController: UIViewController {
    var str3 = String()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
      //  txtvw.text = str3
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        let webView = WKWebView()
        webView.frame  = CGRect(x: 0, y: 0, width: self.view.bounds.width, height:  self.view.bounds.height)
        self.view.addSubview(webView)
        
        webView.scrollView.isScrollEnabled = true
        
        let urlString = str3
        let request = URLRequest(url: URL(string: urlString)!)
        webView.load(request)
        
        // let url = URL(string: "https://www.google.com/maps/place/Ankur+Institute+of+Child+Health+Care/@23.040867,72.562904,14z/data=!4m5!3m4!1s0x0:0x7ab5916bd746cdf8!8m2!3d23.0321179!4d72.56863?hl=en-US")
        //myWebView.loadRequest(URLRequest(url: url!))
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
