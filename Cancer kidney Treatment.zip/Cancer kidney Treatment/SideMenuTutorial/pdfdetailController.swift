//
//  pdfdetailController.swift
//  Queen Women Hospital
//
//  Created by adithya on 9/15/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit
import WebKit
class pdfdetailController: UIViewController {
//    @IBOutlet weak var myWebView: UIWebView!
    //var vv = String()
    
    let pdfTitle = "womenhealth"
    let pdfTitles = "healthIssues"

    override func viewDidLoad() {
        super.viewDidLoad()

        customizeNavBar()

        // Do any additional setup after loading the view.
       

        
    }
 
    override func viewWillAppear(_ animated: Bool) {
        
        let webView = WKWebView()
        webView.frame  = CGRect(x: 0, y: -64, width: self.view.bounds.width, height:  self.view.bounds.height+64)
        self.view.addSubview(webView)
        webView.scrollView.isScrollEnabled = true
        
//        let urlString = "http://www.ashwintrivedi.com/gallery.html"
//        let request = URLRequest(url: URL(string: urlString)!)
//        webView.load(request)
        
        if let url = Bundle.main.url(forResource: pdfTitle, withExtension: "pdf") {
            
            let urlRequest = URLRequest(url: url)
            webView.load(urlRequest as URLRequest)
            
            
            
        }
    }
  
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 129/255, green: 191/255, blue: 180/255, alpha: 1)

        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }

}
