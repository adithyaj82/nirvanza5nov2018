//
//  WebViewController.swift
//  Mahrshi
//
//  Created by adithya on 10/5/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit
import WebKit
class WebViewController: UIViewController {
    var vv = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let webView = WKWebView()
        webView.frame  = CGRect(x: 0, y: 0, width: self.view.bounds.width, height:  self.view.bounds.height)
        self.view.addSubview(webView)
        webView.scrollView.isScrollEnabled = true
        
        let urlString = vv
        let request = URLRequest(url: URL(string: urlString)!)
        webView.load(request)
       // let url = URL(string: vv)
         //       webview.loadRequest(URLRequest(url: url!))
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
