//
//  ServicesWebViewController.swift
//  SideMenuTutorial
//
//  Created by adithya on 9/6/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class ServicesWebViewController: UIViewController {
    var vv = String()
    var vvv = String()

    @IBOutlet weak var t1: UITextView!
    
    
    @IBOutlet var img: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

    }

    override func viewWillAppear(_ animated: Bool) {
        customizeNavBar()
        
      img.image = UIImage(named: vvv)
        t1.text = vv
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        
        return .lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 225/255, green: 118/255, blue: 51/255, alpha: 1)

        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
}
