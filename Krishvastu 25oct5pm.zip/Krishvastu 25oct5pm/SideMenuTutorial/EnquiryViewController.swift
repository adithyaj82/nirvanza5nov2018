//
//  EnquiryViewController.swift
//  Mahrshi app
//
//  Created by adithya on 9/6/18.
//  Copyright © 2018 Parth Changela. All rights reserved.
//

import UIKit
import MessageUI
class EnquiryViewController: UIViewController,UITextViewDelegate,UITextFieldDelegate,MFMailComposeViewControllerDelegate {
    
    @IBOutlet weak var menuButton: UIBarButtonItem!
    
    @IBOutlet var userName: ACFloatingTextfield!
    @IBOutlet weak var Email: ACFloatingTextfield!
    @IBOutlet weak var mobileNo: ACFloatingTextfield!
    @IBOutlet weak var txtVNotes: UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()
//        txtVNotes.layer.borderColor = UIColor.black as? CGColor
     //   txtVNotes.layer.borderWidth = 1
        sideMenus()
        customizeNavBar()
        // Do any additional setup after loading the view.
       // txtVNotes.text = "Placeholder for UITextView"
        //txtVNotes.textColor = UIColor.lightGray
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        txtVNotes.layer.borderWidth = 1
        txtVNotes.layer.borderColor = UIColor.black.cgColor
    }
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 225/255, green: 118/255, blue: 51/255, alpha: 1)

        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
//        if txtVNotes.text == "Enter the address" {
//            txtVNotes.text = ""
//            txtVNotes.textColor = UIColor.black
//            txtVNotes.font = UIFont(name: "verdana", size: 18.0)
//        }
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            txtVNotes.resignFirstResponder()
        }
        return true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
//        if txtVNotes.text == "" {
//            txtVNotes.text = "Enter the address"
//            txtVNotes.textColor = UIColor.lightGray
//            txtVNotes.font = UIFont(name: "verdana", size: 13.0)
//        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func configureMailController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        
        mailComposerVC.setToRecipients(["mahrshivastu@gmail.com"])
        //rajucshah@gmail.com
        mailComposerVC.setSubject("Vastu Application Form")
        mailComposerVC.setMessageBody("Name:"+self.userName.text!+"\n"+"Email:"+self.Email.text!+"\n"+"Mobile:"+self.mobileNo.text!+"\n"+"Address:"+self.txtVNotes.text!, isHTML: false)
        
        return mailComposerVC
    }
    
    func showMailError() {
        let sendMailErrorAlert = UIAlertController(title: "Could not send email", message: "Your device could not send email", preferredStyle: .alert)
        let dismiss = UIAlertAction(title: "Ok", style: .default, handler: nil)
        sendMailErrorAlert.addAction(dismiss)
        self.present(sendMailErrorAlert, animated: true, completion: nil)
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func submit(_ sender: Any) {
        if self.userName.text! == ""{
            userName.showErrorWithText(errorText: "Enter Valid Name")
            userName.errorTextColor = UIColor.red
            userName.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            userName.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            userName.showErrorWithText(errorText: "Ok")
            userName.errorTextColor = UIColor.green
            userName.placeHolderColor = UIColor.black
            userName.errorLineColor = UIColor.green
            userName.selectedLineColor =  UIColor.black
            userName.selectedPlaceHolderColor = UIColor.black
            
        }
        if self.Email.text! == ""{
            Email.showErrorWithText(errorText: "Enter Valid Email")
            Email.errorTextColor = UIColor.red
            Email.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            Email.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            Email.showErrorWithText(errorText: "Ok")
            Email.errorTextColor = UIColor.green
            Email.placeHolderColor = UIColor.black
            Email.errorLineColor = UIColor.green
            Email.selectedLineColor =  UIColor.black
            Email.selectedPlaceHolderColor = UIColor.black
            
        }
        if self.mobileNo.text! == ""{
            mobileNo.showErrorWithText(errorText: "Enter valid Mobile")
            mobileNo.errorTextColor = UIColor.red
            mobileNo.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            mobileNo.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            mobileNo.showErrorWithText(errorText: "Ok")
            mobileNo.errorTextColor = UIColor.green
            mobileNo.placeHolderColor = UIColor.black
            mobileNo.errorLineColor = UIColor.green
            mobileNo.selectedLineColor =  UIColor.black
            mobileNo.selectedPlaceHolderColor = UIColor.black
            
        }
        if self.txtVNotes.text! == ""{
            txtVNotes.layer.borderColor = UIColor.red.cgColor
            
        }
        else
        {
            txtVNotes.layer.borderColor = UIColor.green.cgColor
            
        }
        
        
        
        if self.userName.text! == "" || self.Email.text! == "" || self.mobileNo.text! == "" || self.txtVNotes.text! == "" {
            
            
            
            let alert = UIAlertController(title: "Application Form", message: "Please enter all fields", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
        else{
            
            
            
            
            let mailComposeViewController = configureMailController()
            
            if MFMailComposeViewController.canSendMail() {
                self.present(mailComposeViewController, animated: true, completion: nil)
            } else {
                showMailError()
            }
            
        }
        //
    }
    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController")as! HomeViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
