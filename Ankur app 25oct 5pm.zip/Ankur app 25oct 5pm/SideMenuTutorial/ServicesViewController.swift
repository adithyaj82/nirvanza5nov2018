//
//  ServicesViewController.swift
//  Ankur app
//
//  Created by adithya on 9/8/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class ServicesViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet var menuButton: UIBarButtonItem!
    let doctorEdu = ["Pediatric Intensive Care Unit ( PICU )","Neonatal Intensive Care Unit ( NICU )","","Radiology","Indoor Services","","","",""]
    let doctorsList = ["PICU","NICU","Laboratory","Radiology","Indoor Services","Obesity Clinic","Asthma Clinic","Newborn Followup Clinic","Ambulance Services"]
    let doctorImages = ["picu.jpg","nicu.jpg","laboratory.jpg","radiology.JPG","ankurhospital","obesity.jpg","astama clinic.jpg","newborn followup.jpg","ambulance.jpg"]
    
    let doctordata = ["The PICU is the section of the hospital that provides sick children with the highest level of medical care. It differs from other parts of the hospital, like the general medical floors, in that the PICU allows intensive nursing care and monitoring things like heart rate, breathing, and blood pressure continuously.\n\nThe PICU also allows medical staff to provide therapies that might not be available in other parts of the hospital. Some of these more intensive therapies include ventilators (breathing machines) and certain medications that can be given only under close medical supervision.\n\nKids in the PICU might include those with severe breathing problems from asthma, serious infections, certain heart conditions, some complications of diabetes, or those involved in a serious automobile accident or near-drowning.\n\nOur Facilities:\n• Conventional Ventilation\n• High Frequency Ventilation\n• Bipap\n• NIV\n• High flow Nasal Cannula\n• Multipara monitors with IBP\n• Peritoneal dialysis\n• TPN\n• Central O2\n• Syringe pump\n• Infusion Pump\n• In house Neurosonography and ECHO\n\nFor more information Plaease Dail +91 7926583067","The neonatal intensive care unit (NICU) is a special hospital ward that provides medical care for premature babies and sick newborns. If your baby is sent to the NICU, your first question probably will be: What is this place?\n\nWith equipment designed for infants and a hospital staff who have special training in newborn care, the NICU is an intensive care unit created for sick newborns who need specialized treatment.\n\nSometimes a NICU is called also:\n• The particular care nursery\n• The intensive attention nursery\n• Newborn intensive care babies who require to go to the unit are frequently included within the first 24 hours after birth.\n\n• Babies may be directed to the NICU whether they are born untimely, troubles happen during their delivery, or they show signs of a problem in the first few days of their lives Not every twin needs to stay in the NICU after birth. However, for a subset of twins, the NICU provides a temporary abode for healing and growing prior to their homecoming. Many twins bypass the NICU and go straight home. Babies born between twentyfour and thirty-four weeks may spend several weeks to months in the NICU.\n• A typical NICU may host the following medical staff: Neonatologists are pediatricians with three years of specialized training in the care of premature and sick newborns. They oversee the medical care of all the NICU babies. Pediatric hospitalists are pediatricians who specialize in the care of hospitalized children.\n\nOur Facilities:\n• Conventional Ventilation\n• High Frequency Ventilation\n• CPAP\n• NIV\n• High flow Nasal Cannula\n• Multipara monitors with IBP\n• Peritoneal dialysis\n• TPN\n• Exchange Transfusion\nCentral O2\n• Syringe pump\n• Warmers\n• Phototherapy\n• In house Neurosonography and ECHO\n\nFor more information Plaease Dail +91 7926583067","• Laboratory place equipped for experimental study in a science or for testing and anlysis a research laboratory.\n\n• broadly a place providing oppurtunity for experimentation,observation,or practice in a field of study\n\n1.Diagnostic Laboratory Services:\nDiagnostic Laboratory Services is committed to providing the highest quality drug testing services through the State's most experienced Toxicology staff. We have been providing companies and physicians with timely and accurate drug testing results and support services. Let our customer services associates help you with your workplace or medical drug testing needs.\n\n2.Toxicology\n• Medical/ Clinical Toxicology\n• Workplace Drug Testing\n• Occupational Medical Lab Tests\n• Personal Drug Testing (VERI-5)\n\n3. Pathology\n• Clinical Pathology\n• Surgical Pathology\n• Special Cytology\n• Frozen Section Diagnosis\n\n4. Microbiology\n• Bacteriology cultures\n• Mycology cultures (fungus)\n• Chlamydia cultures\n• Legionella testing","Radiology is the science that uses medical imaging to diagnose and sometimes also treat diseases within the body.\n\nAnkur Institute of child healthProviding impatient and outpatient pediatric imaging services to infants and children,as well as expectant mothers,our pediatric radiologists have advanced training and over years of combined expeerience in pediatric imaging.\n\nNoninvasive and minimally invasive proceduresand used whenever possible.Anesthesia and sedation services are available,when medically appropriate,to provide a more complete and less stressful exam for the patient and family.\n\nFor more information Plaease Dail +91 7926583067","All services necessary for emergency and critical care are located adjacent to each other, either on the same floor or adjoining floors (connected by dedicated elevators).\n\nThese services include :\n• Radiology,\n• Surgery,\n• Laboratory,\n• Pharmacy,\n• Pediatric ICU and\n• Urgent Care.\n\nThis location planning improves care for children requiring multidisciplinary emergency or trauma services.\n\nFor more information Plaease Dail +91 7926583067","Obesity is a complex condition influenced by environmental, social, economic, behavioral and genetic factors. Our innovative multidisciplinary programs and interventions address these factors from the perspective of children and their families.\n\nThe Obesity Clinic of Ankur Institute of child Health emphasizes personalises clinical care and educate to trevent and reduce the prevalence of Obesity.\n\nAnkur Obesity Clinic Features :\n• Personalized care\n• Family-centered programs\n• Care for children to young adults\n\nFor more information Plaease Dail +91 7926583067","Ankur Institute of Child health provides comprehensive, highly specialized care for patients with moderate to severe asthma.\n\nOur services include :\n•Diagnostic testing\n•Physiologic and allergic evaluation\n•Optimization of medical management\n•Education in asthma self-management\n\nWe also have ongoing research studies on asthma treatment. Interested patients may be able to participate in these studies on their request.\n\nFor more information Plaease Dail +91 7926583067","Newborn Followup Clinic:\nAnkur Institute of Child health is multi speciality centre for new born and children. One hospital in Ahmedabad having availability of a competent and dedicated intensive care team of Neonatal.\n\nHigh Risk Newborn Follow-up Clinic. The clinic looks at and follows the progress of children that are at risk for developmental delays.\n\nFor more information Plaease Dail +91 7926583067","Ambulance Services:\nAnkur Institue of child health provide superior quality 24 hour medical and ambulance services.\n\nThe humanitarian mode of our work has led to our rates being largely cost effective. Our ambulances contain all the modern equipments necessary for patients and our medical team is hard working enough to retain customers faith in us.\n\nFor more information Plaease Dail +91 7926583067"]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return doctorsList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! ServicesTableViewCell
        cell.doctorList.text = doctorsList[indexPath.row]
        // cell.imageviewss.image = UIImage(named: doctorImages[indexPath.row])
        
        cell.borderLayer.layer.cornerRadius = 15
        cell.borderLayer.layer.masksToBounds = false
        
        cell.borderLayer.layer.shadowOpacity = 0.78
        cell.borderLayer.layer.shadowOffset = CGSize(width: 0, height: 2)
        cell.borderLayer.layer.shadowRadius = 7
        cell.borderLayer.layer.shadowColor = UIColor.black.cgColor
        cell.borderLayer.layer.masksToBounds = false
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vmim = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetail")as! ServicesDetailViewController
        vmim.str4 =  doctorEdu[indexPath.row]
        vmim.str5 =  doctorImages[indexPath.row]
        vmim.str6 =  doctordata[indexPath.row]
  self.navigationController?.pushViewController(vmim, animated: true)
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sideMenus()
        customizeNavBar()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
