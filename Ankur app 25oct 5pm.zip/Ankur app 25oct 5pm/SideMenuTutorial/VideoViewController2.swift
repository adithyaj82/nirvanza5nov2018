//
//  VideoViewController2.swift
//  Ankur
//
//  Created by adithya on 10/16/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class VideoViewController2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func falilities(_ sender: Any) {
        let v = self.storyboard?.instantiateViewController(withIdentifier: "VideoDetail")as! VideoDetailViewController
        v.vv = "https://www.youtube.com/watch?v=ILWIDETrO6I"
        self.navigationController?.pushViewController(v, animated: true)
    }
    
    @IBAction func Rajushah(_ sender: Any) {
        let v = self.storyboard?.instantiateViewController(withIdentifier: "VideoDetail")as! VideoDetailViewController
        v.vv = "https://www.youtube.com/watch?v=etkO4ykP6RU"
        self.navigationController?.pushViewController(v, animated: true)
    }

}
