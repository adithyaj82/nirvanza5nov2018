//
//  FacilitiesViewController.swift
//  Ankur app
//
//  Created by adithya on 9/9/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class FacilitiesViewController: UIViewController {
    
    @IBOutlet var txt: UITextView!
    @IBOutlet weak var menuButton: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sideMenus()
        customizeNavBar()
        // Do any additional setup after loading the view.
        
        txt.text = "• 60 bed dedicated Superspeciality Neonatal and Pediatric Hospital\n• 13 Bed NICU of Level III Beds.\n• 8  Bed Pediatric Intensive care unit.\n• In house Pediatricians, with round the clock availability of Neonatologist, Pediatric Intensivist, Pediatric and Neonatal surgeon and experts of all the fields.\n• In house facility of Pathology, Radiology (including Sonography and CT scan) and Pharmacy.\n• Fully functional Pediatric and Neonatal intensive care unit with Conventional and high frequency ventilators, CPAP, High flow (Airvo 2), Multipara monitors, Invasive Blood pressure monitoring, CVP monitoring, warmers, phototherapy, pulse oxymeter, syringe pumps and infusion pumps.\n• Ambulance with all facilities for transporting newborns and Pediatric patients from any part of Gujarat.\n• Super Deluxe, Deluxe, Standard Special rooms, Semi special rooms and General wards.\n• We have state of art facilities with dedicated team of the most experienced Pediatrician, Neonatologist and Pediatric Intensivist to cater the needs of the vulnerable and critical neonatal and pediatric patients.\n• NICU\n• Conventional VentilationHigh Frequency Ventilation CPAP\n• High flow Nasal Cannula Multipara monitors with IBP Peritoneal dialysis\n• TPN\n• Exchange Transfusion\n• Central O2\n• Warmers\n• Phototherapy\n• Syringe pump\n• In house Neurosonography and ECHO\n• PICU\n• Bipap\n• NIV\n• Infusion Pump\n• OPD\nFor more information Please Dial  +91 7926583067"
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
          
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 47/255, green: 181/255, blue: 175/255, alpha: 1)
       
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
