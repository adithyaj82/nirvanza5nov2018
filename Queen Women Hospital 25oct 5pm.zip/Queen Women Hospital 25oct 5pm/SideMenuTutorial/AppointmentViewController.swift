//
//  AppointmentViewController.swift
//  Ankur app
//
//  Created by adithya on 9/9/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit
import MessageUI

class AppointmentViewController: UIViewController,MFMailComposeViewControllerDelegate,UITextFieldDelegate,UITextViewDelegate {
    let ac = ACFloatingTextfield()
    @IBOutlet var l1: UILabel!
    
    @IBOutlet var radioButton3: RadioButton!
    @IBOutlet var radioButton4: RadioButton!
    @IBOutlet var reasonVisit: UITextView!
    
    lazy var radioButtons: [RadioButton] = {
        return [self.radioButton3,self.radioButton4]
    }()
    @IBAction func onFourthRadioButtonClicked(_ sender: RadioButton) {
        updateRadioButton(sender)
        l1.text = "New User"
        
        
    }
    @IBAction func onThirdRadioButtonClicked(_ sender: RadioButton) {
        updateRadioButton(sender)
        l1.text = "Existing User"
    }
    
    
    func updateRadioButton(_ sender: RadioButton){
        radioButtons.forEach { $0.isSelected = false }
        sender.isSelected = !sender.isSelected
        
    }
    
    func getSelectedRadioButton() -> RadioButton? {
        var radioButton: RadioButton?
        radioButtons.forEach { if($0.isSelected){ radioButton =  $0 } }
        return radioButton
    }
    
    

    @IBOutlet var userName: ACFloatingTextfield!
    @IBOutlet weak var Email: ACFloatingTextfield!
    @IBOutlet weak var mobileNo: ACFloatingTextfield!
    @IBOutlet weak var address: UITextView!
    @IBOutlet weak var menuButton: UIBarButtonItem!
    let datepicker = UIDatePicker()
    let timepicker = UIDatePicker()

    @IBOutlet var txttimepic: UITextField!
    @IBOutlet var txtdatepic: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        customizeNavBar()
        sideMenus()
        createDatepicker()
        createTimepicker()
        // Do any additional setup after loading the view.
        address.layer.borderColor = UIColor.black.cgColor
        address.layer.borderWidth = 1
        reasonVisit.layer.borderColor = UIColor.black.cgColor
        reasonVisit.layer.borderWidth = 1
    }
    func getRandomColor() -> UIColor{
        let randomRed:CGFloat = CGFloat(drand48())
        let randomGreen:CGFloat = CGFloat(drand48())
        let randomBlue:CGFloat = CGFloat(drand48())
        return UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 1.0)
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool
    {
        if text == "\n"{
            textView.resignFirstResponder()
            return false
        }
        return true
    }
   
    
    func createDatepicker(){
        datepicker.datePickerMode = .date
        let toolbar = UIToolbar()
        let doneButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.done, target: nil, action: #selector(doneClicked))
        toolbar.sizeToFit()
        txtdatepic.inputView = datepicker
        toolbar.setItems([doneButton], animated: true)
        txtdatepic.inputAccessoryView = toolbar

    }
    func doneClicked(){
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
       // dateFormatter.timeStyle = .none
        
        txtdatepic.text = dateFormatter.string(from: datepicker.date)
        self.view.endEditing(true)
        
    }
    func createTimepicker(){
        timepicker.datePickerMode = .time
        let toolbar = UIToolbar()
        let doneButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.done, target: nil, action: #selector(doneTimeClicked))
        toolbar.sizeToFit()
        txttimepic.inputView = timepicker
        toolbar.setItems([doneButton], animated: true)
        txttimepic.inputAccessoryView = toolbar
        
    }
    func doneTimeClicked(){
        let dateFormatter = DateFormatter()
        //dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .short
        
        txttimepic.text = dateFormatter.string(from: timepicker.date)
        self.view.endEditing(true)
        
    }
//    @IBAction func datepic2(_ sender: Any) {
////    let newDate = NSDate(dateString:"2015-12-25")
//       // datepicker.date = newDate
//
//    }
//    @IBAction func datepic(_ sender: Any) {
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = "dd-MM-YYYY"
//        let strDate = dateFormatter.string(from: datepicker.date)
//        txtdatepic.text = strDate
//    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
      
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 167/255, green: 55/255, blue: 140/255, alpha: 1)
    
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    func configureMailController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        
        mailComposerVC.setToRecipients(["rajucshah@gmail.com"])
        //rajucshah@gmail.com
        mailComposerVC.setSubject("Patient Form")
        mailComposerVC.setMessageBody("Name:"+self.userName.text!+"\n"+"Mobile:"+self.mobileNo.text!+"\n"+"Date:"+self.txtdatepic.text!+"\n"+"Time:"+self.txttimepic.text!+"\n"+"Email:"+self.Email.text!+"\n"+"Address:"+self.address.text!+"\n"+"Patient:"+self.l1.text!+"\n"+"Reason For Visit:"+self.reasonVisit.text!
            , isHTML: false)
        
        return mailComposerVC
    }
    
    func showMailError() {
        let sendMailErrorAlert = UIAlertController(title: "Could not send email", message: "Your device could not send email", preferredStyle: .alert)
        let dismiss = UIAlertAction(title: "Ok", style: .default, handler: nil)
        sendMailErrorAlert.addAction(dismiss)
        self.present(sendMailErrorAlert, animated: true, completion: nil)
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
   
  
    @IBAction func submit(_ sender: Any) {
        if self.userName.text! == ""{
            userName.showErrorWithText(errorText: "Enter valid Text")
                        userName.errorTextColor = UIColor.red
                        userName.placeHolderColor = UIColor.red
                userName.selectedPlaceHolderColor = UIColor.red

        }
        else
        {
            userName.showErrorWithText(errorText: "Ok")
                        userName.errorTextColor = UIColor.green
                        userName.placeHolderColor = UIColor.black
                        userName.errorLineColor = UIColor.green
                        userName.selectedLineColor =  UIColor.black
                        userName.selectedPlaceHolderColor = UIColor.black

        }
        if self.mobileNo.text! == ""{
            mobileNo.showErrorWithText(errorText: "Enter valid Text")
            mobileNo.errorTextColor = UIColor.red
            mobileNo.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            mobileNo.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            mobileNo.showErrorWithText(errorText: "Ok")
            mobileNo.errorTextColor = UIColor.green
            mobileNo.placeHolderColor = UIColor.black
            mobileNo.errorLineColor = UIColor.green
            mobileNo.selectedLineColor =  UIColor.black
            mobileNo.selectedPlaceHolderColor = UIColor.black
            
        }
         if self.Email.text! == ""{
            Email.showErrorWithText(errorText: "Enter valid Text")
            Email.errorTextColor = UIColor.red
            Email.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            Email.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            Email.showErrorWithText(errorText: "Ok")
            Email.errorTextColor = UIColor.green
            Email.placeHolderColor = UIColor.black
            Email.errorLineColor = UIColor.green
            Email.selectedLineColor =  UIColor.black
            Email.selectedPlaceHolderColor = UIColor.black
            
        }
   
        if self.address.text == ""{
            address.layer.borderColor = UIColor.red.cgColor
           
        }
        else
        {
          address.layer.borderColor = UIColor.black.cgColor

        }
       
        

        if self.userName.text! == "" || self.Email.text! == "" || self.mobileNo.text! == "" || self.address.text! == "" || self.txtdatepic.text! == "" || self.txttimepic.text! == ""||self.l1.text! == ""||self.reasonVisit.text! == ""{



            let alert = UIAlertController(title: "Application Form", message: "Please enter all fields", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)

        }
        else{




            let mailComposeViewController = configureMailController()

            if MFMailComposeViewController.canSendMail() {
                self.present(mailComposeViewController, animated: true, completion: nil)
            } else {
                showMailError()
            }

        }
//
    }
    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
