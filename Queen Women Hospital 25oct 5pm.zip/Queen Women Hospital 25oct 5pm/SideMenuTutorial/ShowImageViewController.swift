//
//  ViewController.swift
//  testibg
//
//  Created by adithya on 9/14/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit

class ShowImageViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
   
    
    let arraaa = ["a.jpg","c.jpg","d.jpg","facilityfirst.jpg"]
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arraaa.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)as! CollectionViewCell
        cell.imgg.image = UIImage(named:arraaa[indexPath.row])
       
        return cell
    }
  

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       

    }

   


}

