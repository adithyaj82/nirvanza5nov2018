//
//  NewsUpdateDetailViewController.swift
//  testibg
//
//  Created by adithya on 9/14/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit

class NewsUpdateDetailViewController: UIViewController {

    @IBOutlet var b6: UIButton!
    @IBOutlet var b5: UIButton!
    @IBOutlet var b4: UIButton!
    @IBOutlet weak var menuButton: UIBarButtonItem!

    @IBOutlet var h1: UIView!
    @IBOutlet var h2: UIView!
    @IBOutlet var h3: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        customizeNavBar()
        sideMenus()
        b4.backgroundColor = UIColor.orange
        h1.isHidden = false
        h2.isHidden = true
        h3.isHidden = true
    }
    
    @IBAction func b1(_ sender: Any) {
        b4.backgroundColor = UIColor.orange
        b5.backgroundColor = UIColor.white
        b6.backgroundColor = UIColor.white
        h1.isHidden = false
        h2.isHidden = true
        h3.isHidden = true

    }
    
    
    @IBAction func b2(_ sender: Any) {
        b5.backgroundColor = UIColor.orange
        b6.backgroundColor = UIColor.white
         b4.backgroundColor = UIColor.white
        h1.isHidden = true
        h2.isHidden = false
        h3.isHidden = true

    }
    
    @IBAction func b3(_ sender: Any) {
        b6.backgroundColor = UIColor.orange
        b4.backgroundColor = UIColor.white
        b5.backgroundColor = UIColor.white
        h1.isHidden = true
        h2.isHidden = true
        h3.isHidden = false
        
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 167/255, green: 55/255, blue: 140/255, alpha: 1)
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    

    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
