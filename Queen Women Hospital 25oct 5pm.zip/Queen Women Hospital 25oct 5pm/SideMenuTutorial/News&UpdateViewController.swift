//
//  News&UpdateViewController.swift
//  Ankur app
//
//  Created by adithya on 9/14/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class News_UpdateViewController: UIViewController,UITextFieldDelegate {
    @IBOutlet weak var menuButton: UIBarButtonItem!

    @IBOutlet var password: ACFloatingTextfield!
    @IBOutlet var email: ACFloatingTextfield!
    override func viewDidLoad() {
        super.viewDidLoad()
        sideMenus()
        customizeNavBar()
        // Do any additional setup after loading the view.
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 167/255, green: 55/255, blue: 140/255, alpha: 1)
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
    }
    
    @IBAction func Submit(_ sender: Any) {
        if email.text == "" || password.text == ""{
            
            let alert = UIAlertController(title: "News & Update", message: "Please enter all fields", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)

        }else{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "NewsUpdateDetailViewController")as! NewsUpdateDetailViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
    }
    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
