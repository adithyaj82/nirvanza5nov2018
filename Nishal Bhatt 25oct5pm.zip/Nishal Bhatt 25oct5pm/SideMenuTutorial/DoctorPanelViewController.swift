//
//  VastuViewController.swift
//  Mahrshi app
//
//  Created by adithya on 9/6/18.
//  Copyright © 2018 Parth Changela. All rights reserved.
//

import UIKit

class DoctorPanelViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet var menuButton: UIBarButtonItem!
    let doctorsList = ["A SIMPLE FEBRILE SEIZURE","BABY WALKERS","BECOMING A FATHER","BIRTH OF A SECOND CHILD","COPING WITH NIGHT TERRORS","FEVER IS A FRIENDS"]
    
    let doctordata = ["http://www.drnishchalbhatt.co.in/a-simple-febrile-seizure.php","http://www.drnishchalbhatt.co.in/baby-walkers.php","http://www.drnishchalbhatt.co.in/becoming-a-father.php","http://www.drnishchalbhatt.co.in/birth-of-a-second-child.php","http://www.drnishchalbhatt.co.in/coping-with-night-terrors.php","http://www.drnishchalbhatt.co.in/fever-is-a-friends.php"]
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return doctorsList.count
    }
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! DoctorPanelTableViewCell
        cell.doctorList.text = doctorsList[indexPath.row]

        cell.borderLayer.layer.cornerRadius = 15
        cell.borderLayer.layer.masksToBounds = false

        cell.borderLayer.layer.shadowOpacity = 0.78
        cell.borderLayer.layer.shadowOffset = CGSize(width: 0, height: 2)
        cell.borderLayer.layer.shadowRadius = 7
        cell.borderLayer.layer.shadowColor = UIColor.black.cgColor
        cell.borderLayer.layer.masksToBounds = false
        
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vmim = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetail")as! ServicesDetailViewController

       // let vmi = self.storyboard?.instantiateViewController(withIdentifier: "Doctor")as! DoctorPanelDetailViewController
        vmim.str3 =  doctordata[indexPath.row]
        self.navigationController?.pushViewController(vmim, animated: true)

    }
     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sideMenus()
        customizeNavBar()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 146/255, green: 166/255, blue: 68/255, alpha: 1)

        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    
    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
