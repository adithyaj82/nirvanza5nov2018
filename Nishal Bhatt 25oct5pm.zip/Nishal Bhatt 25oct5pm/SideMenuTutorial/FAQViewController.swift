//
//  FAQViewController.swift
//  Nishal Bhatt
//
//  Created by adithya on 10/6/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class FAQViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet var menuButton: UIBarButtonItem!
    let faqList = ["FAQ BOYS & GIRLS","MYTH & FACT","TOP 10 QUESTIONS ASKED BY PARENTS OR TEENEGERS"]
    let urldata = ["http://www.drnishchalbhatt.co.in/images/pdf/faq-boys-&-girls.pdf","http://www.drnishchalbhatt.co.in/images/pdf/myth-or-fact.pdf","http://www.drnishchalbhatt.co.in/images/pdf/top-10-question-asked-by-parents-of-teenagers.pdf"]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return faqList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! FAQTableViewCell
        cell.doctorList.text = faqList[indexPath.row]
        // cell.imageviewss.image = UIImage(named: doctorImages[indexPath.row])
        
        cell.borderLayer.layer.cornerRadius = 15
        cell.borderLayer.layer.masksToBounds = false
        
        cell.borderLayer.layer.shadowOpacity = 0.78
        cell.borderLayer.layer.shadowOffset = CGSize(width: 0, height: 2)
        cell.borderLayer.layer.shadowRadius = 7
        cell.borderLayer.layer.shadowColor = UIColor.black.cgColor
        cell.borderLayer.layer.masksToBounds = false
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       // let cell = tableView.cellForRow(at: indexPath)
        
        let vmim = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetail")as! ServicesDetailViewController

           // let vmim = self.storyboard?.instantiateViewController(withIdentifier: "FAQDetail")as! FAQDetailViewController
            vmim.str3 = urldata[indexPath.row]
            self.navigationController?.pushViewController(vmim, animated: true)
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sideMenus()
        customizeNavBar()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 146/255, green: 166/255, blue: 68/255, alpha: 1)

        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
