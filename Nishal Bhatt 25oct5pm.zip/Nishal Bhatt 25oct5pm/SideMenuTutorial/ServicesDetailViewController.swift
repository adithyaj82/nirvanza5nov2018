//
//  ServicesDetailViewController.swift
//  Ankur app
//
//  Created by adithya on 9/8/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit
import WebKit
class ServicesDetailViewController: UIViewController {
    var str3 = String()
 //   @IBOutlet weak var myWebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        // labb.text =  str
      //  let url = URL(string: str3)
        //myWebView.loadRequest(URLRequest(url: url!))
        
        //txtvw.text = str3
    }
    override func viewWillAppear(_ animated: Bool) {
        
        let webView = WKWebView()
        webView.frame  = CGRect(x: 0, y: 64, width: self.view.bounds.width, height:  self.view.bounds.height)
        self.view.addSubview(webView)
        webView.scrollView.isScrollEnabled = true
        
        let urlString = str3
        let request = URLRequest(url: URL(string: urlString)!)
        webView.load(request)
        
        //let url = URL(string: str3)
        //myWebView.loadRequest(URLRequest(url: url!))
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
}
