//
//  FAQDetailViewController.swift
//  Nishal Bhatt
//
//  Created by adithya on 10/6/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit
import WebKit
class FAQDetailViewController: UIViewController {
    var str3 = String()
   // @IBOutlet weak var myWebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    override func viewWillAppear(_ animated: Bool) {
        let webView = WKWebView()
        webView.frame  = CGRect(x: 0, y: -64, width: self.view.bounds.width, height:  self.view.bounds.height+64)
        self.view.addSubview(webView)
        webView.scrollView.isScrollEnabled = true
        
        let urlString = str3
        let request = URLRequest(url: URL(string: urlString)!)
        webView.load(request)
        
       // let url = URL(string: str3)
        //myWebView.loadRequest(URLRequest(url: url!))
        
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
}
