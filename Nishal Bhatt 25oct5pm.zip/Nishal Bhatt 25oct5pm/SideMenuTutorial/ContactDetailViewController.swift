//
//  VideoDetailViewController.swift
//  Ankur app
//
//  Created by adithya on 9/9/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit
import WebKit
class ContactDetailViewController: UIViewController {
    
 //   @IBOutlet weak var myWebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     
        customizeNavBar()
        // Do any additional setup after loading the view.
        
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        
        let webView = WKWebView()
        webView.frame  = CGRect(x: 0, y: 0, width: self.view.bounds.width, height:  self.view.bounds.height)
        self.view.addSubview(webView)
        webView.scrollView.isScrollEnabled = true
        
        let urlString = "https://www.google.com/maps/place/Radha+Apartments,+100+Feet+Anand+Nagar+Rd,+Jodhpur,+Ahmedabad,+Gujarat+380015/@23.0128167,72.5194495,17z/data=!3m1!4b1!4m5!3m4!1s0x395e84d53ce679cf:0xf9c1e7d612a60953!8m2!3d23.0128167!4d72.5216382?hl=en-US"
        let request = URLRequest(url: URL(string: urlString)!)
        webView.load(request)
        
       // let url = URL(string: "https://www.google.com/maps/place/Radha+Apartments,+100+Feet+Anand+Nagar+Rd,+Jodhpur,+Ahmedabad,+Gujarat+380015/@23.0128167,72.5194495,17z/data=!3m1!4b1!4m5!3m4!1s0x395e84d53ce679cf:0xf9c1e7d612a60953!8m2!3d23.0128167!4d72.5216382?hl=en-US")
     //   myWebView.loadRequest(URLRequest(url: url!))
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 146/255, green: 166/255, blue: 68/255, alpha: 1)

        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    
    
}
