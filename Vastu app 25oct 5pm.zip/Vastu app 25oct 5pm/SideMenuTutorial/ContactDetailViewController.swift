//
//  VideoDetailViewController.swift
//  Ankur app
//
//  Created by adithya on 9/9/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit
import WebKit
class ContactDetailViewController: UIViewController {
    
  //  @IBOutlet weak var myWebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        customizeNavBar()
        // Do any additional setup after loading the view.
        
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        let webView = WKWebView()
        webView.frame  = CGRect(x: 0, y: 0, width: self.view.bounds.width, height:  self.view.bounds.height)
        self.view.addSubview(webView)
        webView.scrollView.isScrollEnabled = true
        
        let urlString = "https://www.google.com/maps/place/Astrologer+Ashwin+Trivedi+(+Vastu+Specialist+)/@23.235236,72.4893584,17z/data=!3m1!4b1!4m5!3m4!1s0x395e84777925d7ff:0x800b9ff0b7212e15!8m2!3d23.235236!4d72.4915524?hl=en-US"
        let request = URLRequest(url: URL(string: urlString)!)
        webView.load(request)
        
     //   let url = URL(string: "https://www.google.com/maps/place/Astrologer+Ashwin+Trivedi+(+Vastu+Specialist+)/@23.235236,72.4893584,17z/data=!3m1!4b1!4m5!3m4!1s0x395e84777925d7ff:0x800b9ff0b7212e15!8m2!3d23.235236!4d72.4915524?hl=en-US")
      //  myWebView.loadRequest(URLRequest(url: url!))

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 252/255, green: 102/255, blue: 45/255, alpha: 1)

        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    
    
}
