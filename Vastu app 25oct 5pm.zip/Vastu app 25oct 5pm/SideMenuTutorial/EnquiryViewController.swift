//
//  EnquiryViewController.swift
//  vastu consultant
//
//  Created by adithya on 9/2/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit
import MessageUI
class EnquiryViewController: UIViewController,UITextViewDelegate,MFMailComposeViewControllerDelegate {
    @IBOutlet weak var message: UITextView!
    @IBOutlet var name: ACFloatingTextfield!
    @IBOutlet var companyName: ACFloatingTextfield!
    
    @IBOutlet var contactNo: ACFloatingTextfield!
    @IBOutlet var email: ACFloatingTextfield!
    
    
    
    @IBOutlet weak var menuButton: UIBarButtonItem!

    
    
    
    @IBOutlet weak var address: UITextView!
  //  @IBOutlet weak var scrollview: UIScrollView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        address.layer.borderWidth = 1
        address.layer.borderColor = UIColor.black.cgColor
        message.layer.borderWidth = 1
        message.layer.borderColor = UIColor.black.cgColor

      
       // self.scrollview.contentSize = CGSize(width: 200, height: 1700)
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool
    {
        if text == "\n"{
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
    }
    @IBAction func web(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
   
    func configureMailController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        
        mailComposerVC.setToRecipients(["ashwintrivedi55@yahoo.com"])
        //rajucshah@gmail.com
        mailComposerVC.setSubject("Vastu Application Form")
        mailComposerVC.setMessageBody("Name:"+self.name.text!+"\n"+"companyName:"+self.companyName.text!+"\n"+"contactNo:"+self.contactNo.text!+"\n"+"Email:"+self.email.text!+"Address:"+self.address.text!+"Message:"+self.message.text!, isHTML: false)
        
        return mailComposerVC
    }
    
    func showMailError() {
        let sendMailErrorAlert = UIAlertController(title: "Could not send email", message: "Your device could not send email", preferredStyle: .alert)
        let dismiss = UIAlertAction(title: "Ok", style: .default, handler: nil)
        sendMailErrorAlert.addAction(dismiss)
        self.present(sendMailErrorAlert, animated: true, completion: nil)
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func submit(_ sender: Any) {
        if name.text! == ""{
            name.showErrorWithText(errorText: "Enter valid Text")
            name.errorTextColor = UIColor.red
            name.placeHolderColor = UIColor.red
            name.selectedPlaceHolderColor = UIColor.red
        }
        else{
            name.showErrorWithText(errorText: "Ok")
            name.errorTextColor = UIColor.green
            name.placeHolderColor = UIColor.black
            name.errorLineColor = UIColor.green
            name.selectedLineColor =  UIColor.black
            name.selectedPlaceHolderColor = UIColor.black
        }
        if  companyName.text! == ""{
            companyName.showErrorWithText(errorText: "Enter valid Text")
            companyName.errorTextColor = UIColor.red
            companyName.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            companyName.selectedPlaceHolderColor = UIColor.red
            
        }else{
            companyName.showErrorWithText(errorText: "Ok")
            companyName.errorTextColor = UIColor.green
            companyName.placeHolderColor = UIColor.black
            companyName.errorLineColor = UIColor.green
            companyName.selectedLineColor =  UIColor.black
            companyName.selectedPlaceHolderColor = UIColor.black
        }
        if contactNo.text! == "" {
            contactNo.showErrorWithText(errorText: "Enter valid Text")
            contactNo.errorTextColor = UIColor.red
            contactNo.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            contactNo.selectedPlaceHolderColor = UIColor.red
        }else{
            contactNo.showErrorWithText(errorText: "Ok")
            contactNo.errorTextColor = UIColor.green
            contactNo.placeHolderColor = UIColor.black
            contactNo.errorLineColor = UIColor.green
            contactNo.selectedLineColor =  UIColor.black
            contactNo.selectedPlaceHolderColor = UIColor.black
        }
        if email.text! == ""{
            email.showErrorWithText(errorText: "Enter valid Text")
            email.errorTextColor = UIColor.red
            email.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            email.selectedPlaceHolderColor = UIColor.red
        }
        else{
            email.showErrorWithText(errorText: "Ok")
            email.errorTextColor = UIColor.green
            email.placeHolderColor = UIColor.black
            email.errorLineColor = UIColor.green
            email.selectedLineColor =  UIColor.black
            email.selectedPlaceHolderColor = UIColor.black
        }
//        if address.text == ""{
//            address.layer.borderColor = UIColor.red as! CGColor
//            address.layer.borderWidth = 2
//        }
//        else{
//            address.layer.borderColor = UIColor.green as! CGColor
//            address.layer.borderWidth = 2
//            
//        }
//        if message.text == ""{
//            message.layer.borderColor = UIColor.red as! CGColor
//             message.layer.borderWidth = 2
//        }
//        else{
//            message.layer.borderColor = UIColor.green as! CGColor
//            message.layer.borderWidth = 2
//
//        }
        if name.text! == "" || companyName.text! == "" || contactNo.text! == "" || email.text! == "" ||  message.text! == "" || address.text! == ""
        {
            let alert = UIAlertController(title: "Application Form", message: "Please enter all fields", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            
        }
        else{
        let mailComposeViewController = configureMailController()
        
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            showMailError()
        }
    }
    }
    override func viewWillAppear(_ animated: Bool) {
        customizeNavBar()
        sideMenus()
        
    }
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 252/255, green: 102/255, blue: 45/255, alpha: 1)
        
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
 

    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
