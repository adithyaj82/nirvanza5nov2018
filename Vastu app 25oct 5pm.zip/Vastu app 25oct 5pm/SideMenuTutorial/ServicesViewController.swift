//
//  ServicesViewController.swift
//  Vastu app
//
//  Created by adithya on 10/8/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class ServicesViewController: UIViewController {
    @IBOutlet weak var menuButton: UIBarButtonItem!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        sideMenus()
        customizeNavBar()
    }
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 252/255, green: 102/255, blue: 45/255, alpha: 1)
        
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    @IBAction func ash(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "https://ashwintrivedi.com/astrology.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func face(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "https://ashwintrivedi.com/facereading.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func palm(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "https://ashwintrivedi.com/palmreading.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func kundli(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "https://ashwintrivedi.com/kundali.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func astrological(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "https://ashwintrivedi.com/astroconsultant.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func hawaan(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "https://ashwintrivedi.com/hawanpuja.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func astro(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "https://ashwintrivedi.com/astroconsultant.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func dosha(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "https://ashwintrivedi.com/doshanivaran.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func yantra(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "https://ashwintrivedi.com/yantras.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func rudrak(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "https://ashwintrivedi.com/rudraksha.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func horoscop(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "https://ashwintrivedi.com/horoscope.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func palmist(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "https://ashwintrivedi.com/palmist.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func reiki(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "https://ashwintrivedi.com/reiki.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func web(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
}
