//
//  KundliViewController.swift
//  vastu consultant
//
//  Created by adithya on 9/2/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit
import MessageUI

class KundliViewController: UIViewController,MFMailComposeViewControllerDelegate {

    @IBOutlet var boyname: ACFloatingTextfield!
    @IBOutlet var boybirthplace: ACFloatingTextfield!
    @IBOutlet var boybirthdate: ACFloatingTextfield!
    @IBOutlet var boybirthtime: ACFloatingTextfield!

    
    @IBOutlet var girlname: ACFloatingTextfield!
    @IBOutlet var girlbirthplace: ACFloatingTextfield!
    @IBOutlet var girlbirthdate: ACFloatingTextfield!
    @IBOutlet var girlbirthtime: ACFloatingTextfield!

    
    @IBOutlet weak var menuButton: UIBarButtonItem!

    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        sideMenus()
        customizeNavBar()
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool
    {
        if text == "\n"{
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    func textViewDidEndEditing(_ textView: UITextView) {
//        if textView.text == "" {
//            textView.text = "Enter your address"
//            textView.textColor = UIColor.lightGray
//
//        }
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
//        if textView.text == "Enter your address" {
//            textView.text = ""
//            textView.textColor = UIColor.black
//        }
//
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
    }
  
    @IBAction func web(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    func configureMailController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        
        mailComposerVC.setToRecipients(["ashwintrivedi55@yahoo.com"])
        //rajucshah@gmail.com
        mailComposerVC.setSubject("Vastu Application Form")
        mailComposerVC.setMessageBody("BOY DETAILS"+"\n"+"Name:"+self.boyname.text!+"\n"+"Birth Place:"+self.boybirthplace.text!+"\n"+"Birth Date:"+self.boybirthdate.text!+"\n"+"Birth Time:"+self.boybirthtime.text!+"\n"+"\n\n"+"GIRL DETAILS"+"\n"+"Name:"+self.girlname.text!+"\n"+"Birth Place:"+self.girlbirthplace.text!+"\n"+"Birth Date:"+self.boybirthdate.text!+"\n"+"Birth Time:"+self.girlbirthtime.text!, isHTML: false)
        
        return mailComposerVC
    }
    
    func showMailError() {
        let sendMailErrorAlert = UIAlertController(title: "Could not send email", message: "Your device could not send email", preferredStyle: .alert)
        let dismiss = UIAlertAction(title: "Ok", style: .default, handler: nil)
        sendMailErrorAlert.addAction(dismiss)
        self.present(sendMailErrorAlert, animated: true, completion: nil)
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func submit(_ sender: Any) {
        if self.boyname.text! == ""{
            boyname.showErrorWithText(errorText: "Enter valid Text")
            boyname.errorTextColor = UIColor.red
            boyname.placeHolderColor = UIColor.red
            boyname.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            boyname.showErrorWithText(errorText: "Ok")
            boyname.errorTextColor = UIColor.green
            boyname.placeHolderColor = UIColor.black
            boyname.errorLineColor = UIColor.green
            boyname.selectedLineColor =  UIColor.black
            boyname.selectedPlaceHolderColor = UIColor.black
            
        }
        if self.boybirthplace.text! == ""{
            boybirthplace.showErrorWithText(errorText: "Enter valid Text")
            boybirthplace.errorTextColor = UIColor.red
            boybirthplace.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            boybirthplace.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            boybirthplace.showErrorWithText(errorText: "Ok")
            boybirthplace.errorTextColor = UIColor.green
            boybirthplace.placeHolderColor = UIColor.black
            boybirthplace.errorLineColor = UIColor.green
            boybirthplace.selectedLineColor =  UIColor.black
            boybirthplace.selectedPlaceHolderColor = UIColor.black
            
        }
        if self.boybirthdate.text! == ""{
            boybirthdate.showErrorWithText(errorText: "Enter valid Text")
            boybirthdate.errorTextColor = UIColor.red
            boybirthdate.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            boybirthdate.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            boybirthdate.showErrorWithText(errorText: "Ok")
            boybirthdate.errorTextColor = UIColor.green
            boybirthdate.placeHolderColor = UIColor.black
            boybirthdate.errorLineColor = UIColor.green
            boybirthdate.selectedLineColor =  UIColor.black
            boybirthdate.selectedPlaceHolderColor = UIColor.black
            
        }
        if self.boybirthtime.text! == ""{
            boybirthtime.showErrorWithText(errorText: "Enter valid Text")
            boybirthtime.errorTextColor = UIColor.red
            boybirthtime.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            boybirthtime.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            boybirthtime.showErrorWithText(errorText: "Ok")
            boybirthtime.errorTextColor = UIColor.green
            boybirthtime.placeHolderColor = UIColor.black
            boybirthtime.errorLineColor = UIColor.green
            boybirthtime.selectedLineColor =  UIColor.black
            boybirthtime.selectedPlaceHolderColor = UIColor.black
            
        }
        
        if self.girlname.text! == ""{
            girlname.showErrorWithText(errorText: "Enter valid Text")
            girlname.errorTextColor = UIColor.red
            girlname.placeHolderColor = UIColor.red
            girlname.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            girlname.showErrorWithText(errorText: "Ok")
            girlname.errorTextColor = UIColor.green
            girlname.placeHolderColor = UIColor.black
            girlname.errorLineColor = UIColor.green
            girlname.selectedLineColor =  UIColor.black
            girlname.selectedPlaceHolderColor = UIColor.black
            
        }
        if self.girlbirthplace.text! == ""{
            girlbirthplace.showErrorWithText(errorText: "Enter valid Text")
            girlbirthplace.errorTextColor = UIColor.red
            girlbirthplace.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            girlbirthplace.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            girlbirthplace.showErrorWithText(errorText: "Ok")
            girlbirthplace.errorTextColor = UIColor.green
            girlbirthplace.placeHolderColor = UIColor.black
            girlbirthplace.errorLineColor = UIColor.green
            girlbirthplace.selectedLineColor =  UIColor.black
            girlbirthplace.selectedPlaceHolderColor = UIColor.black
            
        }
        if self.girlbirthdate.text! == ""{
            girlbirthdate.showErrorWithText(errorText: "Enter valid Text")
            girlbirthdate.errorTextColor = UIColor.red
            girlbirthdate.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            girlbirthdate.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            girlbirthdate.showErrorWithText(errorText: "Ok")
            girlbirthdate.errorTextColor = UIColor.green
            girlbirthdate.placeHolderColor = UIColor.black
            girlbirthdate.errorLineColor = UIColor.green
            girlbirthdate.selectedLineColor =  UIColor.black
            girlbirthdate.selectedPlaceHolderColor = UIColor.black
            
        }
        if self.girlbirthtime.text! == ""{
            girlbirthtime.showErrorWithText(errorText: "Enter valid Text")
            girlbirthtime.errorTextColor = UIColor.red
            girlbirthtime.placeHolderColor = UIColor.red
            // userName.lineColor = UIColor.red
            //userName.selectedLineColor =  UIColor.red
            girlbirthtime.selectedPlaceHolderColor = UIColor.red
            
        }
        else
        {
            girlbirthtime.showErrorWithText(errorText: "Ok")
            girlbirthtime.errorTextColor = UIColor.green
            girlbirthtime.placeHolderColor = UIColor.black
            girlbirthtime.errorLineColor = UIColor.green
            girlbirthtime.selectedLineColor =  UIColor.black
            girlbirthtime.selectedPlaceHolderColor = UIColor.black
            
        }
        if boyname.text! == "" || boybirthplace.text! == "" || boybirthdate.text! == "" || boybirthtime.text! == "" ||  girlname.text! == "" || girlbirthplace.text! == "" || girlbirthdate.text! == "" || girlbirthtime.text! == "" 
        {
            let alert = UIAlertController(title: "Application Form", message: "Please enter all fields", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)

            
        }
        
        else{
        
        
        let mailComposeViewController = configureMailController()
        
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            showMailError()
        }
        
        }
        
        
        
        
    }
   
    
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
            // revealViewController().rightViewRevealWidth = 160
            
            //
            //            alertButton.target = revealViewController()
            //            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
            //
            //
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }
    
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 252/255, green: 102/255, blue: 45/255, alpha: 1)
        
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }

    @IBAction func ds(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
