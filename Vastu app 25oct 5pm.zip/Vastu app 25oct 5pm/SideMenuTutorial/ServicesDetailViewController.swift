//
//  ServicesDetailViewController.swift
//  Ankur app
//
//  Created by adithya on 9/8/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit
import WebKit
class ServicesDetailViewController: UIViewController {
    var vv = String()
    
 //   @IBOutlet var myWebview: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
       
 
    }
    override func viewWillAppear(_ animated: Bool) {
        let webView = WKWebView()
        webView.frame  = CGRect(x: 0, y: -64, width: self.view.bounds.width, height:  self.view.bounds.height+64)
        self.view.addSubview(webView)
        webView.scrollView.isScrollEnabled = true
        
        let urlString = vv
        let request = URLRequest(url: URL(string: urlString)!)
        webView.load(request)
        
       // let url = URL(string: vv)
        //myWebview.loadRequest(URLRequest(url: url!))
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
}
