//
//  WebViewController.swift
//  vastu consultant
//
//  Created by adithya on 9/2/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit
import WebKit

class ArticlesController: UIViewController {
    
    @IBAction func back(_ sender: Any) {
 navigationController?.popViewController(animated: true)
    dismiss(animated: true, completion: nil)
    }
    @IBOutlet weak var myWebView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let webView = WKWebView()
        webView.frame  = CGRect(x: 0, y: 0, width: self.view.bounds.width, height:  self.view.bounds.height)
        self.view.addSubview(webView)
        webView.scrollView.isScrollEnabled = true
        
        let urlString = "http://www.ashwintrivedi.com"
        let request = URLRequest(url: URL(string: urlString)!)
        webView.load(request)
        
       // let url = URL(string: "http://www.ashwintrivedi.com")
        //myWebView.loadRequest(URLRequest(url: url!))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
