//
//  WebsiteDetailViewController.swift
//  Dnsoftech app
//
//  Created by adithya on 10/10/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class WebsiteDetailViewController: UIViewController {
    var str4 = String()
    var str5 = String()
    var str6 = String()
    
    
    @IBOutlet var logoimage: UIImageView!
    
    @IBOutlet var logotitle: UILabel!
    
    @IBOutlet var logodetail: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        logoimage.image = UIImage(named: str4)
        logotitle.text = str5
        logodetail.text = str6
        
    }
    override func viewWillAppear(_ animated: Bool) {
        //   let url = URL(string: str4)
        //   myWebView.loadRequest(URLRequest(url: url!))
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
}
